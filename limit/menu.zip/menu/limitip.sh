#!/bin/bash
# =========================================
# AUTO LIMIT IP XRAY (VMESS/VLESS/TROJAN)
# FIXED & IMPROVED VERSION
# =========================================

LOG_FILE="/var/log/xray/access.log"
CONFIG_FILE="/etc/xray/config.json"

# =========================
# TELEGRAM LOG FUNCTION
# =========================
send_log() {
    local CHATID KEY TIME URL TEXT

    CHATID=$(grep -E "^#bot# " /etc/bot/.bot.db 2>/dev/null | awk '{print $3}')
    KEY=$(grep -E "^#bot# " /etc/bot/.bot.db 2>/dev/null | awk '{print $2}')

    [ -z "$CHATID" ] && return
    [ -z "$KEY" ] && return

    TIME="10"
    URL="https://api.telegram.org/bot${KEY}/sendMessage"

    TEXT="
<code>────────────────────</code>
<b>⚠️ MULTI LOGIN DETECTED ⚠️</b>
<code>────────────────────</code>
<code>Username  : </code><code>${user}</code>
<code>Limit IP  : </code><code>${iplimit}</code>
<code>Total IP : </code><code>${cekcek}</code>
<code>Status    : </code><code>Account Deleted</code>
<code>────────────────────</code>
"

    curl -s --max-time "${TIME}" \
        -d "chat_id=${CHATID}" \
        -d "disable_web_page_preview=1" \
        -d "text=${TEXT}" \
        -d "parse_mode=html" \
        "${URL}" >/dev/null 2>&1
}

# =========================
# GET UNIQUE IP
# =========================
get_ip_count() {
    local username="$1"

    grep -w "$username" "$LOG_FILE" 2>/dev/null \
    | grep -oE '([0-9]{1,3}\.){3}[0-9]{1,3}' \
    | sort -u
}

# =========================
# DELETE USER
# =========================
delete_user() {
    local user="$1"
    local exp="$2"
    local proto="$3"
    local tag="$4"
    local dbfile="$5"

    sed -i "/^${tag} ${user} ${exp}/,/^},{/d" "$CONFIG_FILE"
    sed -i "/^### ${user} ${exp}/d" "$dbfile"

    rm -f "/etc/kyt/limit/${proto}/ip/${user}"

    systemctl restart xray >/dev/null 2>&1
}

# =========================
# VMESS LIMIT IP
# =========================
vmip() {

    [ ! -f "$LOG_FILE" ] && touch "$LOG_FILE"

    for user in $(ls /etc/kyt/limit/vmess/ip 2>/dev/null); do

        iplimit=$(cat /etc/kyt/limit/vmess/ip/"$user" 2>/dev/null)

        ehh=$(get_ip_count "$user")

        cekcek=$(echo "$ehh" | grep -c .)

        if [[ "$cekcek" -gt "$iplimit" ]]; then

            exp=$(grep -w "^### $user" "$CONFIG_FILE" | awk '{print $3}' | head -n1)

            delete_user "$user" "$exp" "vmess" "###" "/etc/vmess/.vmess.db"

            send_log
        fi

        sleep 0.1
    done
}

# =========================
# VLESS LIMIT IP
# =========================
vlip() {

    [ ! -f "$LOG_FILE" ] && touch "$LOG_FILE"

    for user in $(ls /etc/kyt/limit/vless/ip 2>/dev/null); do

        iplimit=$(cat /etc/kyt/limit/vless/ip/"$user" 2>/dev/null)

        ehh=$(get_ip_count "$user")

        cekcek=$(echo "$ehh" | grep -c .)

        if [[ "$cekcek" -gt "$iplimit" ]]; then

            exp=$(grep -w "^#& $user" "$CONFIG_FILE" | awk '{print $3}' | head -n1)

            delete_user "$user" "$exp" "vless" "#&" "/etc/vless/.vless.db"

            send_log
        fi

        sleep 0.1
    done
}

# =========================
# TROJAN LIMIT IP
# =========================
trip() {

    [ ! -f "$LOG_FILE" ] && touch "$LOG_FILE"

    for user in $(ls /etc/kyt/limit/trojan/ip 2>/dev/null); do

        iplimit=$(cat /etc/kyt/limit/trojan/ip/"$user" 2>/dev/null)

        ehh=$(get_ip_count "$user")

        cekcek=$(echo "$ehh" | grep -c .)

        if [[ "$cekcek" -gt "$iplimit" ]]; then

            exp=$(grep -w "^#! $user" "$CONFIG_FILE" | awk '{print $3}' | head -n1)

            delete_user "$user" "$exp" "trojan" "#!" "/etc/trojan/.trojan.db"

            send_log
        fi

        sleep 0.1
    done
}

# =========================
# COMMAND
# =========================
case "$1" in
    vmip)
        vmip
    ;;
    vlip)
        vlip
    ;;
    trip)
        trip
    ;;
    *)
        echo "Usage: $0 {vmip|vlip|trip}"
    ;;
esac
